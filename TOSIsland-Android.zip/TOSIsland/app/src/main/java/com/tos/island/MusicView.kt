package com.tos.island

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

/** مشغّل الموسيقى: غلاف كخلفية + موجة تفاعلية على شريط التقدم (نفس تصميم الفيديو). */
class MusicView(c: Context) : View(c) {
    var expanded = false
    var onCollapse: (() -> Unit)? = null
    var onExpand: (() -> Unit)? = null
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val add = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD) }
    private val path = Path()
    private val B = FloatArray(8)
    private val btn = Array(5) { RectF() }
    private var drag = -1f
    private var liked = false
    private val offs = floatArrayOf(0f, 1.7f, 3.1f)

    private fun ci(a: Float, b: Float, f: Float) = a + (b - a) * (1 - cos(f * PI.toFloat())) / 2f
    private fun fmt(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val t = SystemClock.uptimeMillis().toFloat()
        val real = Hub.live && Hub.bands.sum() > 0.03f
        for (k in 0..7) {
            val v = if (real) Hub.bands[k] else if (Hub.playing) 0.2f + 0.6f * abs(sin(t / 430f + k * 1.7f)) else 0.05f
            B[k] += (v - B[k]) * 0.35f
        }
        val acc = Hub.accent
        cv.drawColor(Color.BLACK)
        if (!expanded) { pill(cv, w, h, acc); if (Hub.playing) postInvalidateOnAnimation(); return }

        val bass = (B[0] + B[1]) / 2
        val cover = Hub.cover
        if (cover != null) {
            val s = max(w / cover.width, h / cover.height) * (1.05f + bass * 0.09f)
            cv.save(); cv.translate(w / 2, h / 2); cv.scale(s, s)
            cv.drawBitmap(cover, -cover.width / 2f, -cover.height / 2f, null); cv.restore()
        } else {
            p.shader = LinearGradient(0f, 0f, w, h, acc, 0xFF05050A.toInt(), Shader.TileMode.CLAMP)
            cv.drawRect(0f, 0f, w, h, p); p.shader = null
        }
        p.shader = LinearGradient(0f, 0f, 0f, h, 0x59000000, 0xB8000000.toInt(), Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w, h, p); p.shader = null

        val pad = 18 * d
        p.style = Paint.Style.FILL; p.color = Color.WHITE; p.alpha = 230; p.textSize = 11 * d
        p.textAlign = Paint.Align.LEFT; cv.drawText("هذا الهاتف", pad, 28 * d, p)
        val txt = if (Hub.title.isEmpty()) "—" else Hub.title + (if (Hub.artist.isNotEmpty()) "  •  " + Hub.artist else "")
        p.alpha = 255; p.textSize = 13 * d; p.isFakeBoldText = true
        val tw = p.measureText(txt); val aw = w - 2 * pad
        cv.save(); cv.clipRect(pad, 38 * d, w - pad, 60 * d)
        if (tw <= aw) { p.textAlign = Paint.Align.CENTER; cv.drawText(txt, w / 2, 53 * d, p) }
        else { val gap = 40 * d; val off = (t / 25f) % (tw + gap); p.textAlign = Paint.Align.LEFT
            cv.drawText(txt, pad - off, 53 * d, p); cv.drawText(txt, pad - off + tw + gap, 53 * d, p) }
        cv.restore(); p.isFakeBoldText = false

        // ---- شريط التقدم + الموجة ----
        val m = 100 * d; val x0 = pad; val x1 = w - pad
        val pos = if (drag >= 0) (drag * Hub.dur).toLong() else Hub.pos + (if (Hub.playing) SystemClock.elapsedRealtime() - Hub.stamp else 0L)
        val fr = if (Hub.dur > 0) (pos.toFloat() / Hub.dur).coerceIn(0f, 1f) else 0f
        val px = x0 + (x1 - x0) * fr
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 5 * d
        p.color = Color.WHITE; p.alpha = 82; cv.drawLine(px, m, x1, m, p)
        val len = px - x0
        if (len > 8 * d) {
            val cols = intArrayOf(acc, Color.WHITE, acc); val als = floatArrayOf(.55f, .3f, .5f); val ks = floatArrayOf(1f, .8f, .62f)
            for (q in 0..2) {
                val xs = ArrayList<Float>(); val ys = ArrayList<Float>()
                var xx = 0f
                while (xx <= len) {
                    val env = sin(PI.toFloat() * min(xx / len, 1f)).pow(.7f)
                    val pos2 = xx / (55 * d) + t / (800f + q * 350f) + offs[q]
                    val i0 = floor(pos2).toInt(); val f = pos2 - i0
                    val v = ci(B[((i0 % 8) + 8) % 8], B[(((i0 + 1) % 8) + 8) % 8], f)
                    val amp = if (Hub.playing) env * ks[q] * (1 + 14 * v * (.45f + .55f * abs(sin(xx / d * .075f + t / 330f + q * 2.1f)))) else 0f
                    xs.add(x0 + xx); ys.add(m - 2 * d - amp * d); xx += 6 * d
                }
                path.reset(); path.moveTo(x0, m); path.lineTo(xs[0], ys[0])
                for (a in 0 until xs.size - 1) path.quadTo(xs[a], ys[a], (xs[a] + xs[a + 1]) / 2, (ys[a] + ys[a + 1]) / 2)
                path.lineTo(px, m); path.close()
                add.style = Paint.Style.FILL; add.color = cols[q]; add.alpha = (als[q] * 255).toInt(); cv.drawPath(path, add)
                if (q == 1) { p.style = Paint.Style.STROKE; p.strokeWidth = 1.2f * d; p.color = Color.WHITE; p.alpha = 230; cv.drawPath(path, p) }
            }
        }
        p.style = Paint.Style.STROKE; p.strokeWidth = 11 * d; p.color = acc; p.alpha = 64; cv.drawLine(x0, m, px, m, p)
        p.strokeWidth = 5 * d; p.alpha = 255; cv.drawLine(x0, m, px, m, p)
        p.style = Paint.Style.FILL; p.color = acc; p.alpha = 80; cv.drawCircle(px, m, 14 * d, p)
        p.color = Color.WHITE; p.alpha = 255; cv.drawCircle(px, m, 9 * d, p)
        p.color = acc; cv.drawCircle(px, m, 6 * d, p)

        p.color = Color.WHITE; p.alpha = 170; p.textSize = 11 * d
        p.textAlign = Paint.Align.LEFT; cv.drawText(fmt(pos), x0, 128 * d, p)
        p.textAlign = Paint.Align.RIGHT; cv.drawText(fmt(Hub.dur), x1, 128 * d, p)

        // ---- أزرار التحكم ----
        val cy = 158 * d
        for (i in 0..4) {
            val cx = x0 + 22 * d + i * (w - 2 * pad - 44 * d) / 4
            btn[i].set(cx - 26 * d, cy - 26 * d, cx + 26 * d, cy + 26 * d)
            if (i in 1..3) { p.style = Paint.Style.FILL; p.color = Color.WHITE; p.alpha = 36; cv.drawCircle(cx, cy, (if (i == 2) 24 else 21) * d, p) }
            icon(cv, i, cx, cy, acc)
        }
        if (Hub.playing || drag >= 0) postInvalidateOnAnimation()
    }

    private fun tri(cv: Canvas, ax: Float, ay: Float, bx: Float, by: Float, cx: Float, cy: Float) {
        path.reset(); path.moveTo(ax, ay); path.lineTo(bx, by); path.lineTo(cx, cy); path.close(); cv.drawPath(path, p)
    }

    private fun icon(cv: Canvas, k: Int, x: Float, y: Float, acc: Int) {
        p.style = Paint.Style.FILL; p.color = Color.WHITE; p.alpha = 255
        when (k) {
            0 -> { p.textAlign = Paint.Align.CENTER; p.textSize = 22 * d; if (liked) p.color = acc; cv.drawText(if (liked) "♥" else "♡", x, y + 8 * d, p) }
            1 -> { cv.drawRect(x - 9 * d, y - 7 * d, x - 7 * d, y + 7 * d, p); tri(cv, x + 8 * d, y - 7 * d, x - 5 * d, y, x + 8 * d, y + 7 * d) }
            2 -> if (Hub.playing) { cv.drawRect(x - 6 * d, y - 8 * d, x - 2 * d, y + 8 * d, p); cv.drawRect(x + 2 * d, y - 8 * d, x + 6 * d, y + 8 * d, p) }
                 else tri(cv, x - 5 * d, y - 8 * d, x + 8 * d, y, x - 5 * d, y + 8 * d)
            3 -> { cv.drawRect(x + 7 * d, y - 7 * d, x + 9 * d, y + 7 * d, p); tri(cv, x - 8 * d, y - 7 * d, x + 5 * d, y, x - 8 * d, y + 7 * d) }
            4 -> { p.style = Paint.Style.STROKE; p.strokeWidth = 2 * d; p.strokeCap = Paint.Cap.ROUND
                cv.drawLine(x - 6 * d, y - 6 * d, x + 6 * d, y + 6 * d, p); cv.drawLine(x + 6 * d, y - 6 * d, x - 6 * d, y + 6 * d, p) }
        }
    }

    /** كبسولة صغيرة: غلاف دائري + أعمدة صغيرة تتفاعل. */
    private fun pill(cv: Canvas, w: Float, h: Float, acc: Int) {
        val r = h / 2 - 5 * d; val cx = h / 2 + 2 * d; val cy = h / 2
        val b = Hub.cover
        if (b != null) {
            val s = min(b.width, b.height)
            cv.save(); path.reset(); path.addCircle(cx, cy, r, Path.Direction.CW); cv.clipPath(path)
            cv.drawBitmap(b, Rect((b.width - s) / 2, (b.height - s) / 2, (b.width + s) / 2, (b.height + s) / 2), RectF(cx - r, cy - r, cx + r, cy + r), null)
            cv.restore()
        } else { p.style = Paint.Style.FILL; p.color = acc; cv.drawCircle(cx, cy, r, p) }
        p.style = Paint.Style.FILL; p.color = acc; p.alpha = 255
        for (k in 0..3) {
            val bh = 4 * d + (h - 16 * d) * B[k * 2]; val bx = w - 16 * d - (3 - k) * 6 * d
            cv.drawRoundRect(bx - 1.5f * d, cy - bh / 2, bx + 1.5f * d, cy + bh / 2, 2 * d, 2 * d, p)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!expanded) { if (e.action == MotionEvent.ACTION_UP) onExpand?.invoke(); return true }
        val x0 = 18 * d; val x1 = width - 18 * d
        when (e.action) {
            MotionEvent.ACTION_DOWN -> if (abs(e.y - 100 * d) < 22 * d && Hub.dur > 0) {
                drag = ((e.x - x0) / (x1 - x0)).coerceIn(0f, 1f); parent.requestDisallowInterceptTouchEvent(true) }
            MotionEvent.ACTION_MOVE -> if (drag >= 0) drag = ((e.x - x0) / (x1 - x0)).coerceIn(0f, 1f)
            MotionEvent.ACTION_UP -> {
                if (drag >= 0) { Hub.controller?.transportControls?.seekTo((drag * Hub.dur).toLong()); Hub.pos = (drag * Hub.dur).toLong(); Hub.stamp = SystemClock.elapsedRealtime(); drag = -1f }
                else { val i = btn.indexOfFirst { it.contains(e.x, e.y) }; val tc = Hub.controller?.transportControls
                    when (i) { 0 -> liked = !liked; 1 -> tc?.skipToPrevious(); 2 -> if (Hub.playing) tc?.pause() else tc?.play(); 3 -> tc?.skipToNext(); 4 -> onCollapse?.invoke() } }
            }
        }
        invalidate(); return true
    }
}
