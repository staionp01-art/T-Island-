package com.tos.island

import android.app.Notification
import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifService : NotificationListenerService() {
    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(m: MediaMetadata?) = refresh()
        override fun onPlaybackStateChanged(s: PlaybackState?) = refresh()
    }

    override fun onListenerConnected() {
        val msm = getSystemService(MediaSessionManager::class.java)
        val cn = ComponentName(this, NotifService::class.java)
        msm.addOnActiveSessionsChangedListener({ pick(it) }, cn)
        pick(msm.getActiveSessions(cn))
    }

    private fun pick(l: List<MediaController>?) {
        val c = l?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: l?.firstOrNull()
        Hub.controller?.unregisterCallback(cb)
        Hub.controller = c
        c?.registerCallback(cb)
        refresh()
    }

    private fun refresh() {
        val c = Hub.controller; val m = c?.metadata; val st = c?.playbackState
        Hub.title = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
        Hub.artist = m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        Hub.setCover(m?.getBitmap(MediaMetadata.METADATA_KEY_ART) ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART))
        Hub.dur = m?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        Hub.playing = st?.state == PlaybackState.STATE_PLAYING
        Hub.pos = st?.position ?: 0L
        Hub.stamp = SystemClock.elapsedRealtime()
        Hub.onChange?.invoke()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification
        val a = n.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true } ?: return
        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        Hub.chat = Hub.Msg(title, text, a, sbn.key)
        Hub.onChange?.invoke()
    }
}
