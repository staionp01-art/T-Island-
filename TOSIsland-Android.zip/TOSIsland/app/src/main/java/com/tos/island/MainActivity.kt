package com.tos.island

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var st: TextView
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Color.parseColor("#07070D")); setPadding((24 * d).toInt(), (56 * d).toInt(), (24 * d).toInt(), (24 * d).toInt()) }
        root.addView(TextView(this).apply { text = "TOS Island"; textSize = 30f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
        st = TextView(this).apply { textSize = 14f; setTextColor(0xCCFFFFFF.toInt()); setPadding(0, (16 * d).toInt(), 0, (16 * d).toInt()) }
        root.addView(st)
        fun btn(t: String, f: () -> Unit) = root.addView(Button(this).apply { text = t; setOnClickListener { f(); refresh() } },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = (8 * d).toInt() })
        btn("1) السماح بالعرض فوق التطبيقات") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        btn("2) السماح بقراءة الإشعارات (الغلاف والرد)") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        btn("3) إذن الصوت (لموجة الموسيقى) والإشعارات") {
            val p = if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS) else arrayOf(Manifest.permission.RECORD_AUDIO)
            requestPermissions(p, 1) }
        btn("▶ تشغيل الجزيرة") { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, IslandService::class.java)) }
        btn("■ إيقاف الجزيرة") { stopService(Intent(this, IslandService::class.java)) }
        setContentView(root); refresh()
    }
    override fun onResume() { super.onResume(); refresh() }
    private fun refresh() {
        val nl = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")?.contains(packageName) == true
        st.text = "العرض فوق التطبيقات: ${if (Settings.canDrawOverlays(this)) "✅" else "❌"}\nقراءة الإشعارات: ${if (nl) "✅" else "❌"}\nإذن الصوت: ${if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == 0) "✅" else "❌"}"
    }
}
