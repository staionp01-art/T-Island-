package com.tos.island

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.media.session.MediaController
import android.os.Bundle

/** الحالة المشتركة بين خدمة الإشعارات وواجهة الجزيرة. */
object Hub {
    class Msg(val sender: String, val text: String, val action: Notification.Action, val key: String)

    var title = ""; var artist = ""
    var cover: Bitmap? = null; var accent: Int = 0xFF8C6BFF.toInt()
    var playing = false; var pos = 0L; var dur = 0L; var stamp = 0L
    var controller: MediaController? = null
    var chat: Msg? = null
    val bands = FloatArray(8); @Volatile var live = false
    var onChange: (() -> Unit)? = null

    fun setCover(b: Bitmap?) {
        cover = b
        if (b != null) {
            val px = Bitmap.createScaledBitmap(b, 1, 1, true).getPixel(0, 0)
            val m = { v: Int -> (v * 0.7f + 76).toInt() }
            accent = Color.rgb(m(Color.red(px)), m(Color.green(px)), m(Color.blue(px)))
        }
    }

    /** رد حقيقي على إشعار الرسالة عبر RemoteInput. */
    fun reply(ctx: Context, text: String) {
        val a = chat?.action ?: return
        val ris = a.remoteInputs ?: return
        val i = Intent(); val b = Bundle()
        ris.forEach { b.putCharSequence(it.resultKey, text) }
        RemoteInput.addResultsToIntent(ris, i, b)
        try { a.actionIntent.send(ctx, 0, i) } catch (_: Exception) {}
    }
}
