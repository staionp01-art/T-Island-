package com.tos.island

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.audiofx.Visualizer
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import kotlin.math.hypot
import kotlin.math.pow

class IslandService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var view: IslandView
    private var viz: Visualizer? = null

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("island", "Island", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "island").setContentTitle("TOS Island").setContentText("الجزيرة تعمل").setSmallIcon(android.R.drawable.ic_media_play).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        view = IslandView(this)
        val nf = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        val lp = WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            nf or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = (8 * resources.displayMetrics.density).toInt()   // عدّلها لتناسب موضع الكاميرا
        view.focusCb = { need -> lp.flags = if (need) lp.flags and nf.inv() else lp.flags or nf; wm.updateViewLayout(view, lp) }
        wm.addView(view, lp)
        startViz()
    }

    private fun startViz() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        try {
            viz = Visualizer(0).apply {
                enabled = false
                captureSize = Visualizer.getCaptureSizeRange()[1]
                setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(v: Visualizer?, w: ByteArray?, r: Int) {}
                    override fun onFftDataCapture(v: Visualizer?, f: ByteArray?, r: Int) {
                        if (f == null) return
                        for (k in 0..7) {
                            var s = 0f
                            for (i in 1 + k * 3..3 + k * 3) s += hypot(f[2 * i].toFloat(), f[2 * i + 1].toFloat())
                            Hub.bands[k] = (s / 3f / 90f).coerceIn(0f, 1f).pow(2.2f)
                        }
                        Hub.live = true
                    }
                }, Visualizer.getMaxCaptureRate() / 2, false, true)
                enabled = true
            }
        } catch (_: Throwable) {}
    }

    override fun onDestroy() {
        try { viz?.release() } catch (_: Throwable) {}
        try { wm.removeView(view) } catch (_: Throwable) {}
        super.onDestroy()
    }
}
