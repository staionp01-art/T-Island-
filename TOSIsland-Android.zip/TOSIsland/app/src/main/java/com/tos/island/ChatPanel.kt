package com.tos.island

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*

/** لوحة الرد السريع: اسم المرسل + الرسالة + ردود جاهزة + حقل كتابة. */
class ChatPanel(c: Context) : LinearLayout(c) {
    var onSend: ((String) -> Unit)? = null
    var onClose: (() -> Unit)? = null
    var onFocus: ((Boolean) -> Unit)? = null
    private val d = resources.displayMetrics.density
    private val name = TextView(c); private val msg = TextView(c); private val ed = EditText(c)

    private fun bg(col: Int, r: Float) = GradientDrawable().apply { setColor(col); cornerRadius = r * d }

    init {
        orientation = VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
        setBackgroundColor(Color.BLACK); setPadding((16 * d).toInt(), (12 * d).toInt(), (16 * d).toInt(), (12 * d).toInt())
        val top = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
        name.setTextColor(Color.WHITE); name.textSize = 15f; name.setTypeface(null, android.graphics.Typeface.BOLD)
        top.addView(name, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        val x = TextView(c).apply { text = "✕"; setTextColor(Color.WHITE); textSize = 16f; setPadding((10 * d).toInt(), 0, (10 * d).toInt(), 0); setOnClickListener { onClose?.invoke() } }
        top.addView(x); addView(top)
        msg.setTextColor(0xCCFFFFFF.toInt()); msg.textSize = 13f; msg.maxLines = 3
        addView(msg, LayoutParams(-1, 0, 1f))
        val qr = LinearLayout(c)
        listOf("تمام 👍", "أنا في الطريق", "بعدين أكلمك").forEach { t ->
            qr.addView(TextView(c).apply { text = t; setTextColor(Color.WHITE); textSize = 12f; background = bg(0x44FFFFFF, 20f)
                setPadding((12 * d).toInt(), (6 * d).toInt(), (12 * d).toInt(), (6 * d).toInt()); setOnClickListener { onSend?.invoke(t) } },
                LayoutParams(-2, -2).apply { marginEnd = (6 * d).toInt() })
        }
        addView(qr, LayoutParams(-2, -2).apply { topMargin = (6 * d).toInt() })
        val row = LinearLayout(c).apply { gravity = Gravity.CENTER_VERTICAL }
        ed.hint = "اكتب ردك…"; ed.setTextColor(Color.WHITE); ed.setHintTextColor(0x88FFFFFF.toInt()); ed.textSize = 13f
        ed.setSingleLine(); ed.imeOptions = EditorInfo.IME_ACTION_SEND; ed.background = bg(0x22FFFFFF, 22f)
        ed.setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
        ed.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) { onFocus?.invoke(true)
                ed.postDelayed({ ed.requestFocus(); (context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(ed, 0) }, 120) }
            false }
        ed.setOnEditorActionListener { _, _, _ -> send(); true }
        row.addView(ed, LayoutParams(0, (40 * d).toInt(), 1f))
        row.addView(TextView(c).apply { text = "➤"; gravity = Gravity.CENTER; setTextColor(Color.BLACK); textSize = 16f
            background = bg(Hub.accent, 20f); setOnClickListener { send() } }, LayoutParams((40 * d).toInt(), (40 * d).toInt()).apply { marginStart = (8 * d).toInt() })
        addView(row, LayoutParams(-1, -2).apply { topMargin = (8 * d).toInt() })
    }

    private fun send() { val t = ed.text.toString().trim(); if (t.isNotEmpty()) onSend?.invoke(t) }
    fun bind(m: Hub.Msg) { name.text = m.sender; msg.text = m.text; ed.setText("") }
    fun sent() {
        msg.text = "✓ تم الإرسال"; ed.setText("")
        (context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(ed.windowToken, 0)
    }
}
