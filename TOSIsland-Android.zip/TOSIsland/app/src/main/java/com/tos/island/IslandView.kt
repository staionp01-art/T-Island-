package com.tos.island

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.Outline
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import kotlin.math.max
import kotlin.math.min

/** الجزيرة نفسها: كبسولة ← موسيقى موسّعة ← رسالة مع رد. */
class IslandView(c: Context) : FrameLayout(c) {
    enum class S { HIDDEN, PILL, MUSIC, CHAT }
    var state = S.HIDDEN
    var focusCb: ((Boolean) -> Unit)? = null
    private val d = resources.displayMetrics.density
    private val box = FrameLayout(c)
    private val music = MusicView(c)
    private val chat = ChatPanel(c)
    private val h = Handler(Looper.getMainLooper())
    private var cw = 0; private var chh = 0; private var shownKey = ""

    init {
        addView(box, LayoutParams(0, 0))
        box.addView(music, LayoutParams(-1, -1)); box.addView(chat, LayoutParams(-1, -1))
        box.setBackgroundColor(Color.BLACK); box.clipToOutline = true
        box.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, min(v.height / 2f, 28 * d)) } }
        box.visibility = GONE; chat.visibility = GONE
        music.onExpand = { set(S.MUSIC) }; music.onCollapse = { set(S.PILL) }
        chat.onSend = { t -> Hub.reply(context, t); chat.sent(); h.postDelayed({ Hub.chat = null; set(rest()) }, 1400) }
        chat.onClose = { Hub.chat = null; set(rest()) }
        chat.onFocus = { focusCb?.invoke(it) }
        Hub.onChange = { h.post { update() } }
    }

    private fun rest() = if (Hub.title.isNotEmpty() && Hub.playing) S.PILL else S.HIDDEN

    private fun update() {
        val m = Hub.chat
        if (m != null && m.key != shownKey) {
            shownKey = m.key; chat.bind(m); set(S.CHAT)
            h.postDelayed({ if (state == S.CHAT && Hub.chat?.key == shownKey) { Hub.chat = null; set(rest()) } }, 9000)
        } else if (state == S.HIDDEN && Hub.title.isNotEmpty() && Hub.playing) set(S.PILL)
        else if (state == S.PILL && (Hub.title.isEmpty() || !Hub.playing)) set(S.HIDDEN)
        music.invalidate()
    }

    fun set(s: S) {
        if (s == state && box.visibility == VISIBLE == (s != S.HIDDEN)) return
        state = s
        val dm = resources.displayMetrics
        val maxW = min(dm.widthPixels - (24 * d).toInt(), (360 * d).toInt())
        val (tw, th) = when (s) {
            S.HIDDEN -> 0 to 0
            S.PILL -> (150 * d).toInt() to (34 * d).toInt()
            S.MUSIC -> maxW to (190 * d).toInt()
            S.CHAT -> maxW to (236 * d).toInt()
        }
        music.expanded = s == S.MUSIC
        music.visibility = if (s == S.CHAT) GONE else VISIBLE
        chat.visibility = if (s == S.CHAT) VISIBLE else GONE
        if (s != S.CHAT) focusCb?.invoke(false)
        box.visibility = VISIBLE
        val w0 = if (cw == 0) (tw * 0.6f).toInt() else cw; val h0 = if (chh == 0) (th * 0.6f).toInt() else chh
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 420; interpolator = OvershootInterpolator(1.1f)
            addUpdateListener {
                val f = it.animatedValue as Float
                val lp = box.layoutParams
                lp.width = max(0, (w0 + (tw - w0) * f).toInt()); lp.height = max(0, (h0 + (th - h0) * f).toInt())
                box.layoutParams = lp; box.invalidateOutline()
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) { cw = tw; chh = th; if (s == S.HIDDEN) box.visibility = GONE }
            })
            start()
        }
        music.invalidate()
    }
}
